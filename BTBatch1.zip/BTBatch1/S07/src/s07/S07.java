    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s07;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class S07 {
/**
     * The main method to start the program.
     *
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        // Create a FileManager instance and show the menu
        FileManager fileManager = new FileManager();
        fileManager.showMenu();
    }
    
}
