/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v11;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class V11 {

    /**
     * Main method to run the GradeManager program. Creates a GradeManager
     * object, reads grades, and prints statistics.
     *
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        // Create a GradeManager object
        GradeManager gradeManager = new GradeManager();
        // Read grades from user input
        gradeManager.readGrades();
        // Print statistics of the grades
        gradeManager.printStatistics();
    }

}
