/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v10;

/**
 * Main class to initiate the grocery store management system.
 */
public class V10 {

    /**
     * Main method to start the program.
     * @param args The command line arguments
     */
    public static void main(String[] args) {
        // Instantiate the GroceryStoreManagement object
        GroceryStoreManagement f = new GroceryStoreManagement();
        
        // Call the groceryStoreManagemet method to begin managing the grocery store
        f.groceryStoreManagemet();
    }

}
