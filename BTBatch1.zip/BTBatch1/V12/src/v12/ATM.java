package v12;

import java.io.*;
import java.util.*;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class ATM {

    private Map<String, Account> accounts = new HashMap<>();
    private Account currentAccount = null;

    /**
     * Constructs an ATM object and loads accounts from file.
     */
    public ATM() {
        loadAccounts();
    }

    /**
     * Loads accounts from a file.
     */
    private void loadAccounts() {
        try (BufferedReader reader = new BufferedReader(new FileReader("accounts.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Account account = Account.fromString(line);
                accounts.put(account.getAccountNumber(), account);
            }
        } catch (IOException e) {
            System.err.println("Error loading accounts: " + e.getMessage());
        }
    }

    /**
     * Saves accounts to a file.
     */
    private void saveAccounts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("accounts.txt"))) {
            for (Account account : accounts.values()) {
                writer.write(account.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving accounts: " + e.getMessage());
        }
    }

    /**
     * Logs in to an account.
     *
     * @param accountNumber The account number.
     * @param pin The PIN.
     * @return true if login is successful, false otherwise.
     */
    public boolean login(String accountNumber, String pin) {
        Account account = accounts.get(accountNumber);
        if (account != null && account.getPin().equals(pin)) {
            currentAccount = account;
            return true;
        }
        return false;
    }

    /**
     * Registers a new account.
     *
     * @param accountNumber The account number.
     * @param pin The PIN.
     * @param accountName The account name.
     * @param balance The initial balance.
     * @param currency The currency.
     */
    public void register(String accountNumber, String pin, String accountName, double balance, String currency) {
        if (!accounts.containsKey(accountNumber)) {
            for (Account account : accounts.values()) {
                if (account.getAccountName().equals(accountName)) {
                    System.out.println("Account with this name already exists!");
                    return;
                }
            }
            Account account = new Account(accountNumber, pin, accountName, balance, currency);
            accounts.put(accountNumber, account);
            saveAccounts();
        } else {
            System.out.println("Account already exists!");
        }
    }

    /**
     * Withdraws money from the current account.
     *
     * @param amount The amount to withdraw.
     */
    public void withdraw(double amount) {
        if (currentAccount != null) {
            if (currentAccount.getBalance() >= amount) {
                currentAccount.setBalance(currentAccount.getBalance() - amount);
                saveAccounts();
                recordTransaction("withdraw", amount);
                System.out.println("Withdraw successful. New balance: " + currentAccount.getBalance());
            } else {
                System.out.println("Insufficient funds.");
            }
        } else {
            System.out.println("You need to login first.");
        }
    }

    /**
     * Transfers money to another account.
     *
     * @param destinationAccountNumber The destination account number.
     * @param amount The amount to transfer.
     */
    public void transfer(String destinationAccountNumber, double amount) {
        if (currentAccount != null) {
            Account destinationAccount = accounts.get(destinationAccountNumber);
            if (destinationAccount != null && currentAccount.getBalance() >= amount) {
                currentAccount.setBalance(currentAccount.getBalance() - amount);
                destinationAccount.setBalance(destinationAccount.getBalance() + amount);
                saveAccounts();
                recordTransaction("transfer", amount);
                System.out.println("Transfer successful. New balance: " + currentAccount.getBalance());
            } else {
                System.out.println("Insufficient funds or invalid destination account.");
            }
        } else {
            System.out.println("You need to login first.");
        }
    }

    /**
     * Records a transaction.
     *
     * @param type The type of transaction.
     * @param amount The amount of the transaction.
     */
    private void recordTransaction(String type, double amount) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("transactions.txt", true))) {
            writer.write(type + "," + currentAccount.getAccountNumber() + "," + amount + "," + new Date());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error recording transaction: " + e.getMessage());
        }
    }
}
