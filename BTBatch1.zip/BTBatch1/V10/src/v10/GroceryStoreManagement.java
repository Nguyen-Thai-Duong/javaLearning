/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v10;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * GroceryStoreManagement: Manages a grocery store inventory system. Allows
 * adding, deleting, modifying items, and saving changes to a file.
 */
public class GroceryStoreManagement {

    private final int MAX_ITEMS = 10;
    private Item[] items = new Item[MAX_ITEMS];
    private int itemCount = 0;
    private boolean saveFlag = false;
    private String originalFilename;

    /**
     * Starts the grocery store management system.
     */
    public void groceryStoreManagemet() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to the grocery store");
        System.out.println("Please input the file you'd like to load int stock.");

        loadDatabase(sc);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1) Add new item");
            System.out.println("2) Delete item");
            System.out.println("3) Change cost of an item");
            System.out.println("4) Search for item");
            System.out.println("5) Display inventory details");
            System.out.println("6) Quit");
            System.out.print("Choose an option: ");
            int choice = getIntInput(sc);

            switch (choice) {
                case 1:
                    addItem(sc);
                    break;
                case 2:
                    deleteItem(sc);
                    break;
                case 3:
                    changeItemCost(sc);
                    break;
                case 4:
                    searchItem(sc);
                    break;
                case 5:
                    displayInventory();
                    break;
                case 6:
                    if (saveFlag) {
                        System.out.print("Do you want to save changes? (yes/no): ");
                        String response = sc.nextLine();
                        if (response.equalsIgnoreCase("yes")) {
                            saveChanges(sc);
                        }
                    }
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Validates integer input.
     *
     * @param sc The Scanner object for user input.
     * @return Valid integer input.
     */
    private int getIntInput(Scanner sc) {
        while (!sc.hasNextInt()) {
            System.out.println("Invalid input. Please enter a numeric value.");
            sc.next(); // Consume invalid input
        }
        int value = sc.nextInt();
        sc.nextLine(); // Consume newline
        return value;
    }

    /**
     * Loads the database from a specified file.
     *
     * @param sc The Scanner object for user input.
     */
    private void loadDatabase(Scanner sc) {
        String filename;
        while (true) {

            filename = sc.nextLine();
            if (!filename.toLowerCase().endsWith(".txt")) {
                System.out.println("Error: File must be a .txt file.");
                continue;
            }

            File file = new File(filename);
            if (file.exists()) {
                originalFilename = filename;
                break;
            } else {
                try {
                    file.createNewFile();
                    originalFilename = filename;
                    break;
                } catch (IOException e) {
                    System.out.println("Error creating file: " + e.getMessage());
                }
            }
        }
        System.out.println(filename + " has been properly loaded into the database");
        try (BufferedReader br = new BufferedReader(new FileReader(originalFilename))) {
            String line;
            while ((line = br.readLine()) != null && itemCount < MAX_ITEMS) {
                String[] parts = line.split(" ");
                if (parts.length < 4) {
                    System.out.println("Error: Invalid data format in file.");
                    continue;
                }
                int id = Integer.parseInt(parts[0].trim());
                String name = parts[1].trim();
                double cost = Double.parseDouble(parts[2].trim());
                String category = parts[3].trim();
                items[itemCount++] = new Item(id, name, cost, category);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    /**
     * Adds a new item to the inventory.
     *
     * @param sc The Scanner object for user input.
     */
   public void addItem(Scanner sc) {
        if (itemCount >= MAX_ITEMS) {
            System.out.println("Inventory is full. cannot add more items.");
            return;
        }
        try {
            System.out.println("What is the ID number of the item to add? ");
            int id = getIntInput(sc);
            System.out.println("What is the name of the item to be added? ");
            String name = sc.nextLine();
            while (name.length() > 15) {
                System.out.println("Error: Item name cannot exceed 15 characters. Please enter a shorter name: ");
                name = sc.nextLine();
            }
            System.out.println("What is the cost of the item to be added? ");
            double cost = Double.parseDouble(sc.nextLine());
            System.out.println("What is the product category of the item to be added? ");
            String category = sc.nextLine();
            for (int i = 0; i < itemCount; i++) {
                if (id == items[i].id) {
                    System.out.println("Sorry, an item with the ID number " + id + " is already in the database.");
                    return;
                }
            }
            items[itemCount++] = new Item(id, name, cost, category);
            saveFlag = true;
            System.out.println(name + " added successfully.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for cost.");
        }
    }

    /**
     * Deletes an item from the inventory based on ID.
     *
     * @param sc The Scanner object for user input.
     */
    public void deleteItem(Scanner sc) {
        try {
            System.out.println("What is the ID number of the product to delete?");
            int id = getIntInput(sc);
            for (int i = 0; i < itemCount; i++) {
                if (items[i].id == id) {
                    String itemName = items[i].name;
                    items[i] = items[itemCount - 1];
                    items[--itemCount] = null;
                    System.out.println(itemName + " have been deleted from the database");
                    saveFlag = true;
                    return;
                }
            }
            System.out.println("Sorry, there is no item in the database with that ID number.");

        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a numeric value for id.");
        }

    }

    /**
     * Changes the cost of an item based on ID.
     *
     * @param sc The Scanner object for user input.
     */
    private void changeItemCost(Scanner sc) {
        try {
            System.out.println("What is the ID number of the item in question?");
            int id = getIntInput(sc);

            for (int i = 0; i < itemCount; i++) {
                if (items[i].id == id) {
                    String itemName = items[i].name;
                    System.out.println("What is the new price for " + itemName);
                    double newCost = Double.parseDouble(sc.nextLine());
                    items[i].cost = newCost;
                    System.out.println(itemName + " now costs " + newCost);
                    saveFlag = true;
                    return;
                }
            }

            System.out.println("Sorry, Item with this id not found.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for cost.");
        }
    }

    /**
     * Searches for an item in the inventory by name.
     *
     * @param sc The Scanner object for user input.
     */
    private void searchItem(Scanner sc) {
        System.out.println("Which item would you like to search for? ");
        String name = sc.nextLine();

        for (int i = 0; i < itemCount; i++) {
            if (items[i].name.equalsIgnoreCase(name)) {

                System.out.println("Here is the product information:");
                System.out.printf("%-10s %-15s %-10s %-15s\n", "ID", "Name", "Cost", "Category");
                System.out.println(items[i]);
                return;
            }
        }

        System.out.println("Sorry, we do not have " + name + " in the store");
    }

    /**
     * Displays the details of all items in the inventory.
     */
    private void displayInventory() {
        System.out.println("\nHere is a listing of all the products in stock:");
        System.out.printf("%-10s %-15s %-10s %-15s\n", "ID", "Name", "Cost", "Category");

        for (int i = 0; i < itemCount; i++) {
            System.out.println(items[i]);
        }
    }

    /**
     * Saves changes to a new file if the save flag is true.
     *
     * @param sc The Scanner object for user input.
     */
    private void saveChanges(Scanner sc) {
        String newFilename;
        while (true) {
            System.out.print("What file would you like to save the new database: ");
            newFilename = sc.nextLine();
            if (newFilename.equals(originalFilename)) {
                System.out.println("New filename cannot be the same as the original filename.");
            } else {
                break;
            }
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(newFilename))) {
            for (int i = 0; i < itemCount; i++) {
                bw.write(items[i].toString());
                bw.newLine();
            }
            System.out.println("The file has been saved. Thanks for shopping!");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}
