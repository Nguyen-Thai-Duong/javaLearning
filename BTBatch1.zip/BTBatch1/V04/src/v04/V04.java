/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v04;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class V04 {

    /**
     * Main method to start the program.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GradeStudent gradeStudent = new GradeStudent();// Create GradeStudent object
        gradeStudent.run();// Run the program
    }
}
