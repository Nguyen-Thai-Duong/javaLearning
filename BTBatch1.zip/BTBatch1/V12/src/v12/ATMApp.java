package v12;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class ATMApp {

    private ATM atm;
    private Scanner scanner;

    /**
     * Constructs an ATMApp object.
     */
    public ATMApp() {
        atm = new ATM();
        scanner = new Scanner(System.in);
    }

    /**
     * Runs the ATM application.
     */
    public void run() {
        System.out.println("Welcome to the ATM");
        while (true) {
            System.out.println("Please choose an option:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");

            int choice = getUserChoice();
            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    if (login()) {
                        boolean loggedIn = true;
                        while (loggedIn) {
                            System.out.println("Please choose an option:");
                            System.out.println("1. Withdraw");
                            System.out.println("2. Transfer");
                            System.out.println("3. Logout");

                            int action = getUserChoice();
                            switch (action) {
                                case 1:
                                    withdraw();
                                    break;
                                case 2:
                                    transfer();
                                    break;
                                case 3:
                                    loggedIn = false;
                                    break;
                                default:
                                    System.out.println("Invalid choice, please try again.");
                            }
                        }
                    }
                    break;
                case 3:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    /**
     * Validates integer input.
     *
     * @return Valid integer input.
     */
    private int getUserChoice() {
        int choice = -1;
        while (true) {
            try {
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, please enter a number.");
                scanner.next();  // Consume invalid input
            }
        }
        return choice;
    }

    /**
     * Registers a new account.
     */
    private void register() {
        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();
        System.out.println("Enter PIN:");
        String pin = scanner.nextLine();
        System.out.println("Enter account name:");
        String accountName = scanner.nextLine();
        System.out.println("Enter initial balance:");
        double balance = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter currency (USD, VND, ...):");
        String currency = scanner.nextLine();

        atm.register(accountNumber, pin, accountName, balance, currency);
    }

    /**
     * Logs in to an account.
     *
     * @return true if login is successful, false otherwise.
     */
    private boolean login() {
        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();
        System.out.println("Enter PIN:");
        String pin = scanner.nextLine();

        if (atm.login(accountNumber, pin)) {
            System.out.println("Login successful");
            return true;
        } else {
            System.out.println("Invalid account number or PIN");
            return false;
        }
    }

    /**
     * Withdraws money from the current account.
     */
    private void withdraw() {
        System.out.println("Enter amount to withdraw:");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        atm.withdraw(amount);
    }

    /**
     * Transfers money to another account.
     */
    private void transfer() {
        System.out.println("Enter destination account number:");
        String destinationAccountNumber = scanner.nextLine();
        System.out.println("Enter amount to transfer:");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        atm.transfer(destinationAccountNumber, amount);
    }
}
