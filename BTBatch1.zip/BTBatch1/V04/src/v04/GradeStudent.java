/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v04;

import java.util.Scanner;

/**
 * GradeStudent class calculates the overall course grade based on midterm,
 * final, and homework scores. It prompts the user to input scores and weights
 * for each component, and then computes the overall grade. The class also
 * provides methods for validating user input.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class GradeStudent {

    private Scanner scanner = new Scanner(System.in);

    /**
     * Runs the program to calculate the overall course grade.
     */
    public void run() {
        begin();
        System.out.println();
        double midTermScore = midTerm(); // Calculate weighted score for midterm
        System.out.println();
        double finalTermScore = finalTerm(); // Calculate weighted score for final exam
        System.out.println();
        double homeworkScore = homework(); // Calculate weighted score for homework
        report(midTermScore, finalTermScore, homeworkScore); // Generate report
    }

    /**
     * Displays the initial message of the program.
     */
    private void begin() {
        System.out.println("This program reads exam/homework scores and reports your overall course grade.");
    }

    /**
     * Truncate a double value to keep only one decimal place.
     *
     * @param value the value to truncate
     * @return the truncated value
     */
    private double truncateToOneDecimal(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    /**
     * Prompts the user for midterm scores and calculates the weighted score.
     *
     * @return the weighted score of the midterm
     */
    private double midTerm() {
        // Implementation code for midterm calculation
        System.out.println("Midterm:");
        double weight = getValidInput("Weight (0-100)? ", 0, 100); // Prompt for weight
        double scoreEarned = getValidInput("Score earned? ", 0, 100); // Prompt for score earned
        double shiftAmount = 0; // Initialize shift amount
        System.out.print("Were scores shifted (1 = yes, 2 = no)? "); // Prompt for score shifting
        int shifted = getValidInput("1 or 2? ", 1, 2);
        if (shifted == 1) {
            shiftAmount = getValidInput("Shift amount? ", 0, 100); // Prompt for shift amount
        }
        double totalPoints = Math.min(scoreEarned + shiftAmount, 100); // Calculate total points
        double weightedScore = (totalPoints / 100) * weight; // Calculate weighted score
        System.out.println("Total points = " + totalPoints + " / 100");
        System.out.println("Weighted score = " + truncateToOneDecimal(weightedScore) + " / " + weight);
        return weightedScore;
    }

    /**
     * Prompts the user for final exam scores and calculates the weighted score.
     *
     * @return the weighted score of the final exam
     */
    private double finalTerm() {
        // Implementation code for final exam calculation
        System.out.println("Final:");
        double weight = getValidInput("Weight (0-100)? ", 0, 100); // Prompt for weight
        double scoreEarned = getValidInput("Score earned? ", 0, 100); // Prompt for score earned
        double shiftAmount = 0; // Initialize shift amount
        System.out.print("Were scores shifted (1 = yes, 2 = no)? "); // Prompt for score shifting
        int shifted = getValidInput("1 or 2? ", 1, 2);
        if (shifted == 1) {
            shiftAmount = getValidInput("Shift amount? ", 0, 100); // Prompt for shift amount
        }
        double totalPoints = Math.min(scoreEarned + shiftAmount, 100); // Calculate total points
        double weightedScore = (totalPoints / 100) * weight; // Calculate weighted score
        System.out.println("Total points = " + totalPoints + " / 100");
        System.out.println("Weighted score = " + truncateToOneDecimal(weightedScore) + " / " + weight);
        return weightedScore;
    }

    /**
     * Prompts the user for homework scores and calculates the weighted score.
     *
     * @return the weighted score of the homework
     */
    private double homework() {
        // Implementation code for homework calculation
        System.out.println("Homework:");
        double weight = getValidInput("Weight (0-100)? ", 0, 100); // Prompt for weight
        System.out.print("Number of assignments? "); // Prompt for number of assignments
        int numAssignments = getValidInput("Enter a positive integer: ", 1, Integer.MAX_VALUE);
        double totalScore = 0; // Initialize total score
        double maxTotalScore = 0; // Initialize maximum total score
        for (int i = 1; i <= numAssignments; i++) {
            totalScore += getValidInput("Assignment " + i + " score? ", 0, 100); // Prompt for assignment score
            maxTotalScore += getValidInput("Assignment " + i + " max? ", 0, 100); // Prompt for maximum assignment score
        }
        System.out.print("How many sections did you attend? "); // Prompt for number of attended sections
        int sectionsAttended = getValidInput("Enter a positive integer: ", 0, Integer.MAX_VALUE);
        double sectionPoints = Math.min(sectionsAttended * 5, 30); // Calculate section points
        System.out.println("Section points = " + sectionPoints + " / 30");
        totalScore += sectionPoints; // Add section points to total score
        maxTotalScore += 30; // Update maximum total score
        double weightedScore = (totalScore / maxTotalScore) * weight; // Calculate weighted score
        System.out.println("Total points = " + totalScore + " / " + maxTotalScore);
        System.out.println("Weighted score = " + weightedScore + " / " + weight);
        return weightedScore;
    }

    /**
     * Generates the report displaying the overall percentage and the minimum
     * possible grade.
     *
     * @param midTermScore the weighted score of the midterm
     * @param finalTermScore the weighted score of the final exam
     * @param homeworkScore the weighted score of the homework
     */
    private void report(double midTermScore, double finalTermScore, double homeworkScore) {
        // Implementation code for generating the report
        double overallPercentage = midTermScore + finalTermScore + homeworkScore; // Calculate overall percentage
        System.out.println("Overall percentage = " + overallPercentage);
        double grade; // Initialize grade
        if (overallPercentage >= 85) {
            grade = 3.0; // Set grade for percentage >= 85
        } else if (overallPercentage >= 75) {
            grade = 2.0; // Set grade for percentage >= 75
        } else if (overallPercentage >= 60) {
            grade = 0.7; // Set grade for percentage >= 60
        } else {
            grade = 0.0; // Set grade for percentage < 60
        }
        System.out.println("Your grade will be at least: " + grade);
    }

    /**
     * Validates and retrieves a valid numerical input from the user.
     *
     * @param prompt the message to prompt the user for input
     * @return the valid numerical input provided by the user
     */
    private int getValidInput(String prompt, int min, int max) {
        // Implementation code for validating user input
        int input;
        do {
            System.out.print(prompt); // Prompt user for input
            while (!scanner.hasNextInt()) { // Check if input is not an integer
                System.out.println("Invalid input. Please enter a valid integer."); // Display error message
                System.out.print(prompt); // Prompt user again
                scanner.next();
            }
            input = scanner.nextInt();
            if (input < min || input > max) {
                System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
            }
        } while (input < min || input > max);
        return input;
    }
}
