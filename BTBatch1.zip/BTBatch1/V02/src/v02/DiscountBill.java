/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class Employee: Represents an employee with a name.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
class Employee {

    private String name; // Member variable to store the employee's name

    // Constructor to initialize Employee with a name
    public Employee(String name) {
        this.name = name;
    }

    // Override toString method to return employee information as a string
    @Override
    public String toString() {
        return "Employee{name='" + name + "'}";
    }
}

/**
 * Class Item: Represents an item with a price and a discount.
 *
 */
class Item {

    private double price;// Member variable to store the item's price
    private double discount;// Member variable to store the item's discount

    // Constructor to initialize Item with price and discount
    public Item(double price, double discount) {
        this.price = price;
        this.discount = discount;
    }

    // Getter to retrieve the price of the item
    public double getPrice() {
        return price;
    }

    // Getter to retrieve the discount of the item
    public double getDiscount() {
        return discount;
    }

    // Override toString method to return item information as a string
    @Override
    public String toString() {
        return "Item{price=" + price + ", discount=" + discount + '}';
    }
}

/**
 * Class DiscountBill: Manages a bill with items, applying discounts if
 * preferred.
 *
 */
public class DiscountBill {

    private Employee clerk; // Member variable to store the clerk handling the bill
    private List<Item> items; // List to store the items in the bill
    private boolean preferred; // Flag to determine if the customer is preferred
    private int discountCount; // Number of items with a discount
    private double discountAmount; // Total amount of discount

    // Constructor to initialize DiscountBill with clerk and preferred status
    public DiscountBill(Employee clerk, boolean preferred) {
        this.clerk = clerk;
        this.items = new ArrayList<>(); // Initialize the items list
        this.preferred = preferred;
        this.discountCount = 0; // Initialize discount count
        this.discountAmount = 0.0; // Initialize discount amount
    }

    /**
     * add: Adds an item to the bill and updates discount information if
     * preferred.
     *
     * @param i The item to add.
     */
    public void add(Item i) {
        items.add(i); // Add item to the list
        // If the customer is preferred and the item has a discount
        if (preferred && i.getDiscount() > 0) {
            discountCount++; // Increment discount count
            discountAmount += i.getDiscount(); // Add to total discount amount
        }
    }

    /**
     * getTotal: Calculates the total price of the bill, applying discounts if
     * preferred.
     *
     * @return The total price of the bill.
     */
    public double getTotal() {
        double total = 0.0; // Initialize total
        // Loop through all items and sum their prices
        for (Item item : items) {
            total += item.getPrice();
        }
        // If the customer is preferred, subtract the total discount amount
        if (preferred) {
            total -= discountAmount;
        }
        return total; // Return the total price
    }

    /**
     * printReceipt: Prints the receipt with item details and totals.
     */
    public void printReceipt() {
        // Print each item
        for (Item item : items) {
            System.out.println(item);
        }
        // Print the total price
        System.out.println("Total: " + getTotal());
        // If the customer is preferred, print additional discount information
        if (preferred) {
            System.out.println("Discounted Items: " + getDiscountCount());
            System.out.println("Total Discount: $" + getDiscountAmount());
            System.out.println("Total after Discount: $" + getTotal());
        }
    }

    /**
     * getDiscountCount: Gets the number of items with discounts.
     *
     * @return The number of discounted items.
     */
    public int getDiscountCount() {
        return discountCount;
    }

    /**
     * getDiscountAmount: Gets the total discount amount.
     *
     * @return The total discount amount.
     */
    public double getDiscountAmount() {
        return discountAmount;
    }

    /**
     * getDiscountPercent: Calculates the discount percentage.
     *
     * @return The discount percentage.
     */
    public double getDiscountPercent() {
        double total = 0.0; // Initialize total
        // Loop through all items and sum their prices
        for (Item item : items) {
            total += item.getPrice();
        }
        // Calculate and return the discount percentage
        return (total > 0) ? (discountAmount / total) * 100 : 0;
    }

    /**
     * runTest: Runs a test of the DiscountBill functionality by interacting
     * with the user.
     */
    public static void runTest() {
        Scanner scanner = new Scanner(System.in); // Create Scanner object for input

        // Prompt user for the clerk's name and create Employee object
        System.out.print("Enter clerk's name: ");
        String clerkName = scanner.nextLine();
        Employee clerk = new Employee(clerkName);

        // Prompt user to check if the customer is preferred
        System.out.print("Is the customer preferred (true/false)? ");
        boolean preferred = scanner.nextBoolean();

        // Create DiscountBill object with clerk and preferred status
        DiscountBill bill = new DiscountBill(clerk, preferred);

        // Prompt user to enter items
        System.out.println("Enter items (price and discount). Type 'done' to finish:");

        // Loop to read item inputs
        while (true) {
            // Prompt user for item price
            System.out.print("Enter item price: ");
            String input = scanner.next();
            if (input.equalsIgnoreCase("done")) {
                break; // Exit loop if user types 'done'
            }
            double price = Double.parseDouble(input); // Parse price

            // Prompt user for item discount
            System.out.print("Enter item discount: ");
            double discount = scanner.nextDouble();

            // Add item to the bill
            bill.add(new Item(price, discount));
        }

        // Print the receipt
        bill.printReceipt();

        // Print discount details
        System.out.println("Discount Count: " + bill.getDiscountCount());
        System.out.println("Discount Amount: " + bill.getDiscountAmount());
        System.out.println("Discount Percent: " + bill.getDiscountPercent());

        scanner.close(); // Close the scanner
    }
}
