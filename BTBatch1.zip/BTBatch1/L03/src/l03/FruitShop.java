package l03;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.Scanner;

public class FruitShop {
    private ArrayList<Fruit> fruits;
    private Hashtable<String, Order> orders;

    public FruitShop() {
        fruits = new ArrayList<>();
        orders = new Hashtable<>();
    }

    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("FRUIT SHOP SYSTEM");
            System.out.println("1. Create Fruit");
            System.out.println("2. View orders");
            System.out.println("3. Shopping (for buyer)");
            System.out.println("4. Exit");
            System.out.print("Please choose: ");
            int choice = 0;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next(); // Clear the invalid input
                continue;
            }
            switch (choice) {
                case 1:
                    createFruit(scanner);
                    break;
                case 2:
                    viewOrders();
                    break;
                case 3:
                    shopping(scanner);
                    break;
                case 4:
                    System.out.println("Thank you for using Fruit Shop System.");
                    return;
                default:
                    System.out.println("Invalid choice. Please choose again.");
            }
        }
    }

    private void createFruit(Scanner scanner) {
        String id = "";
        while (true) {
            System.out.print("Enter Fruit Id (numeric): ");
            id = scanner.next();
            if (id.matches("\\d+")) {
                break;
            } else {
                System.out.println("Invalid input. Fruit Id should be numeric. Please try again.");
            }
        }

        String name = "";
        while (true) {
            System.out.print("Enter Fruit Name (max 15 characters): ");
            name = scanner.next();
            if (name.length() <= 15) {
                break;
            } else {
                System.out.println("Invalid input. Fruit Name should be at most 15 characters. Please try again.");
            }
        }

        double price = 0;
        while (true) {
            System.out.print("Enter Price: ");
            try {
                price = scanner.nextDouble();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number for the price.");
                scanner.next(); // Clear the invalid input
            }
        }

        int quantity = 0;
        while (true) {
            System.out.print("Enter Quantity: ");
            try {
                quantity = scanner.nextInt();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number for the quantity.");
                scanner.next(); // Clear the invalid input
            }
        }

        System.out.print("Enter Origin: ");
        String origin = scanner.next();

        Fruit fruit = new Fruit(id, name, price, quantity, origin);
        fruits.add(fruit);
        System.out.println("Do you want to order now (Y/N)? ");
        String orderNow = scanner.next();
        if (orderNow.equalsIgnoreCase("Y")) {
            shopping(scanner);
        }
    }

    private void viewOrders() {
        for (Order order : orders.values()) {
            System.out.println("Customer: " + order.getCustomerName());
            System.out.println("+-----+-----------------+----------+-------+--------+");
            System.out.println("| No. | Product         | Quantity | Price | Amount |");
            System.out.println("+-----+-----------------+----------+-------+--------+");
            double total = 0;
            for (int i = 0; i < order.getFruits().size(); i++) {
                Fruit fruit = order.getFruits().get(i);
                int quantity = order.getQuantities().get(i);
                double amount = fruit.getPrice() * quantity;
                total += amount;
                System.out.printf("| %3d | %-15s | %8d | %5.2f | %6.2f |\n", i + 1, fruit.getName(), quantity, fruit.getPrice(), amount);
            }
            System.out.println("+-----+-----------------+----------+-------+--------+");
            System.out.printf("| TOTAL                 |          |       | %6.2f |\n", total);
            System.out.println("+-----+-----------------+----------+-------+--------+");
        }
    }

    private void shopping(Scanner scanner) {
        while (true) {
            System.out.println("List of Fruit:");
            System.out.println("+-----+-----------------+-------------+-------+");
            System.out.println("| No. | Fruit Name      | Origin      | Price |");
            System.out.println("+-----+-----------------+-------------+-------+");
            for (int i = 0; i < fruits.size(); i++) {
                Fruit fruit = fruits.get(i);
                System.out.printf("| %3d | %-15s | %-11s | %5.2f |\n", i + 1, fruit.getName(), fruit.getOrigin(), fruit.getPrice());
            }
            System.out.println("+-----+-----------------+-------------+-------+");
            System.out.print("Please select item: ");
            int item = scanner.nextInt();
            if (item < 1 || item > fruits.size()) {
                System.out.println("Invalid item. Please select again.");
                continue;
            }
            Fruit selectedFruit = fruits.get(item - 1);
            System.out.println("You selected: " + selectedFruit.getName());
            System.out.print("Please input quantity: ");
            int quantity = scanner.nextInt();
            System.out.println("Do you want to order now (Y/N)? ");
            String orderNow = scanner.next();
            if (orderNow.equalsIgnoreCase("Y")) {
                System.out.print("Input your name: ");
                String customerName = scanner.next();
                Order order = orders.getOrDefault(customerName, new Order(customerName));
                order.addFruit(selectedFruit, quantity);
                orders.put(customerName, order);
                System.out.println("Order placed successfully.");
                break;
            }
        }
    }
}
