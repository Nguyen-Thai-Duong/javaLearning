/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v11;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class GradeManager {

    private ArrayList<Integer> grades;

    /**
     * Constructor for GradeManager. Initializes an empty list to store grades.
     */
    public GradeManager() {
        this.grades = new ArrayList<>();
    }

    /**
     * Reads grades from user input. Continues to read until the user inputs
     * -999. Only valid grades between 0 and 100 are added to the list. Invalid
     * inputs are handled by prompting the user to enter a valid integer.
     */
    public void readGrades() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the grades (enter -999 to finish):");
        int grade;
        while (true) {
            try {
                // Read the next integer input from the user
                grade = scanner.nextInt();
                // Break the loop if the user inputs -999
                if (grade == -999) {
                    break;
                }
                // Add the grade to the list if it's between 0 and 100
                if (grade >= 0 && grade <= 100) {
                    grades.add(grade);
                } else {
                    System.out.println("Please enter a grade between 0 and 100.");
                }
            } catch (InputMismatchException e) {
                // Handle invalid input by prompting the user to enter a valid integer
                System.out.println("Invalid input. Please enter an integer value.");
                scanner.next(); // Clear the invalid input
            }
        }
    }

    /**
     * Prints a histogram of the grades. The histogram shows the frequency of
     * grades in intervals of 5.
     */
    public void printHistogram() {
        // Array to hold the frequency of each grade interval
        int[] frequency = new int[21];
        // Calculate the frequency of each grade interval
        for (int grade : grades) {
            frequency[grade / 5]++;
        }
        // Print the histogram
        for (int i = 0; i < frequency.length; i++) {
            System.out.printf("%2d-%2d | ", i * 5, i * 5 + 4);
            for (int j = 0; j < frequency[i]; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }

    /**
     * Finds the index of the maximum grade in the list.
     *
     * @return The index of the maximum grade.
     */
    public int findMax() {
        return grades.indexOf(Collections.max(grades));
    }

    /**
     * Finds the index of the minimum grade in the list.
     *
     * @return The index of the minimum grade.
     */
    public int findMin() {
        return grades.indexOf(Collections.min(grades));
    }

    /**
     * Removes the grade at the specified index from the list.
     *
     * @param index The index of the grade to be removed.
     */
    public void removeElement(int index) {
        grades.remove(index);
    }

    /**
     * Calculates the mean of the grades in the list.
     *
     * @return The mean of the grades.
     */
    public double calculateMean() {
        int sum = 0;
        // Calculate the sum of all grades
        for (int grade : grades) {
            sum += grade;
        }
        // Return the mean value
        return (double) sum / grades.size();
    }

    /**
     * Calculates the standard deviation of the grades in the list.
     *
     * @return The standard deviation of the grades.
     */
    public double calculateStandardDeviation() {
        double mean = calculateMean();
        double sum = 0;
        // Calculate the sum of the squared differences from the mean
        for (int grade : grades) {
            sum += Math.pow(grade - mean, 2);
        }
        // Return the standard deviation
        return Math.sqrt(sum / grades.size());
    }

    /**
     * Prints the statistics of the grades. Prints the minimum and maximum
     * values (and removes them from the list), the mean, the standard
     * deviation, and the histogram.
     */
    public void printStatistics() {
        // Find and print the minimum grade, then remove it from the list
        int minIndex = findMin();
        int minValue = grades.get(minIndex);
        System.out.printf("Min value: %.2f\n", (double) minValue);
        removeElement(minIndex);

        // Find and print the maximum grade, then remove it from the list
        int maxIndex = findMax();
        int maxValue = grades.get(maxIndex);
        System.out.printf("Max value: %.2f\n", (double) maxValue);
        removeElement(maxIndex);

        // Print the mean and standard deviation of the remaining grades
        System.out.printf("Mean: %.2f\n", calculateMean());
        System.out.printf("Standard Deviation: %.2f\n", calculateStandardDeviation());

        // Print the histogram of the remaining grades
        printHistogram();
    }
}
