/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s02;

import java.util.Scanner;

/**
 * Menu class: Provides a menu for interacting with the binary conversion
 * program.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class menu {

    private Converter converter = new Converter();
    private InputHandler inputHandler = new InputHandler();
    private OutputHandler outputHandler = new OutputHandler();
    private Scanner scanner = new Scanner(System.in);

    /**
     * run: Executes the binary conversion program.
     */
    public void run() {
        boolean running = true;
        while (running) {
            String input = inputHandler.getInput();
            if (input.equalsIgnoreCase("exit")) {
                running = false;
                continue;
            }
            String binaryResult = converter.convertToBinary(input);
            if (binaryResult != null) {
                outputHandler.displayBinary(binaryResult);
            } else {
                System.out.println(outputHandler.getErrorMessage());
            }
            inputHandler.waitForInput();
            System.out.println(); // Printing an empty line
        }
        System.out.println("Exiting the program...");
    }
}
