/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v03;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CSVProcessor class handles operations related to importing, formatting, and exporting CSV data.
 * It includes methods for importing CSV, formatting address and name fields,
 * and exporting the processed data back to CSV.
 * <p>
 * The menu-driven interface allows users to interactively choose operations.
 * </p>
 * @author Nguyen Thai Duong _ CE180478
 */
public class CSVProcessor {
    private List<String[]> dataCSV = new ArrayList<>(); // Stores CSV data as a list of string arrays

    /**
     * Main method to run the CSV processing application.
     */
    public void run() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            displayMenu(); // Display menu options
            int choice = 0;

            while (true) {
                System.out.print("Please choose one option (1-5): ");
                String input = scanner.nextLine();
                try {
                    choice = Integer.parseInt(input);
                    if (choice < 1 || choice > 5) {
                        System.out.println("Invalid option. Please enter a number from 1 to 5");
                    } else {
                        break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid option. Please enter a number from 1 to 5.");
                }
            }

            try {
                switch (choice) {
                    case 1:
                        importCSV(scanner); // Import CSV data from file
                        break;
                    case 2:
                        formatAddress(); // Format address fields
                        System.out.println("Successfully formatted address.");
                        break;
                    case 3:
                        formatName(); // Format name fields
                        System.out.println("Successfully formatted name.");
                        break;
                    case 4:
                        exportCSV(scanner); // Export formatted data back to CSV
                        break;
                    case 5:
                        System.out.println("Exit.");
                        return; // Exit the program
                    default:
                        System.out.println("Invalid option.");
                        break;
                }
            } catch (IOException e) {
                System.out.println("Error processing file: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    /**
     * Displays the menu options for the CSV processing application.
     */
    private void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Import CSV");
        System.out.println("2. Format Address");
        System.out.println("3. Format Name");
        System.out.println("4. Export CSV");
        System.out.println("5. Exit");
    }

    /**
     * Imports CSV data from a specified file path.
     * 
     * @param scanner Scanner object for user input.
     */
    private void importCSV(Scanner scanner) {
        while (true) {
            System.out.print("Please enter the path to the CSV file: ");
            String importPath = scanner.nextLine();
            if (!Files.exists(Paths.get(importPath))) {
                System.out.println("File not found: " + importPath);
                continue;
            }
            try (BufferedReader br = new BufferedReader(new FileReader(importPath))) {
                String line;
                dataCSV.clear(); // Clear previous data before loading new data
                while ((line = br.readLine()) != null) {
                    dataCSV.add(line.split(",")); // Split each line by comma and add to dataCSV
                }
                System.out.println("CSV input successful.");
                break;
            } catch (IOException e) {
                System.out.println("Error reading file: " + e.getMessage());
            }
        }
    }

    /**
     * Formats the address fields in the CSV data by trimming extra spaces.
     */
    private void formatAddress() {
        for (String[] row : dataCSV) {
            if (row.length > 4) {
                row[4] = row[4].trim().replaceAll(" +", " "); // Trim and replace multiple spaces with single space
            }
        }
    }

    /**
     * Formats the name fields in the CSV data by capitalizing each word.
     */
    private void formatName() {
        for (String[] row : dataCSV) {
            if (row.length > 1) {
                row[1] = Arrays.stream(row[1].trim().split(" +"))
                        .map(word -> word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase())
                        .collect(Collectors.joining(" ")); // Capitalize each word in the name
            }
        }
    }

    /**
     * Exports the formatted CSV data to a specified file path.
     * 
     * @param scanner Scanner object for user input.
     * @throws IOException If an I/O error occurs.
     */
    private void exportCSV(Scanner scanner) throws IOException {
        System.out.print("Please enter the file name for export: ");
        String exportPath = scanner.nextLine();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(exportPath))) {
            for (String[] row : dataCSV) {
                bw.write(String.join(",", row)); // Join array elements with comma and write to file
                bw.newLine(); // Write new line for each row
            }
        }
        System.out.println("CSV export successful.");
    }
}