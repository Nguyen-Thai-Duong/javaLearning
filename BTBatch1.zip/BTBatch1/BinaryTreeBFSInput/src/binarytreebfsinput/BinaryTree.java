/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package binarytreebfsinput;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class BinaryTree {
    Node root; // Gốc của cây nhị phân

    // Constructor
    public BinaryTree() {
        root = null; // Khởi tạo cây với gốc ban đầu là null
    }

    // Phương thức duyệt cây theo chiều rộng (BFS)
    void BFS() {
        Queue<Node> queue = new LinkedList<>(); // Khởi tạo một hàng đợi để lưu trữ các node
        queue.add(root); // Thêm gốc vào hàng đợi

        while (!queue.isEmpty()) { // Khi hàng đợi không rỗng
            Node tempNode = queue.poll(); // Lấy và xóa node đầu hàng đợi
            System.out.print(tempNode.value + " "); // In giá trị của node

            if (tempNode.left != null) { // Nếu có con trái
                queue.add(tempNode.left); // Thêm con trái vào hàng đợi
            }
            if (tempNode.right != null) { // Nếu có con phải
                queue.add(tempNode.right); // Thêm con phải vào hàng đợi
            }
        }
    }

    // Phương thức chèn node dựa trên đầu vào của người dùng
    void insertNode(Node node, int value, String direction) {
        if (direction.equalsIgnoreCase("left")) { // Nếu hướng là "left"
            node.left = new Node(value); // Chèn node vào bên trái
        } else if (direction.equalsIgnoreCase("right")) { // Nếu hướng là "right"
            node.right = new Node(value); // Chèn node vào bên phải
        }
    }

    // Phương thức in cây nhị phân dưới dạng cấu trúc
    void printTree() {
        int height = treeHeight(root); // Tính chiều cao của cây
        int width = (int) Math.pow(2, height) - 1; // Tính độ rộng của cây

        Queue<Node> queue = new LinkedList<>(); // Khởi tạo một hàng đợi để lưu trữ các node
        queue.add(root); // Thêm gốc vào hàng đợi

        for (int i = 0; i < height; i++) { // Duyệt qua từng cấp của cây
            int levelNodes = (int) Math.pow(2, i); // Số lượng node ở cấp hiện tại
            int spaceBetween = (int) Math.pow(2, height - i) - 1; // Khoảng cách giữa các node
            int leadingSpaces = (spaceBetween - 1) / 2; // Khoảng cách đầu tiên

            printSpaces(leadingSpaces); // In khoảng cách đầu tiên
            for (int j = 0; j < levelNodes; j++) { // Duyệt qua từng node ở cấp hiện tại
                Node node = queue.poll(); // Lấy và xóa node đầu hàng đợi
                if (node != null) { // Nếu node không null
                    System.out.print(node.value); // In giá trị của node
                    queue.add(node.left); // Thêm con trái vào hàng đợi
                    queue.add(node.right); // Thêm con phải vào hàng đợi
                } else {
                    System.out.print(" "); // In khoảng trắng nếu node null
                    queue.add(null); // Thêm null vào hàng đợi
                    queue.add(null); // Thêm null vào hàng đợi
                }
                printSpaces(spaceBetween); // In khoảng cách giữa các node
            }
            System.out.println(); // Xuống dòng sau khi in xong một cấp
        }
    }

    // Phương thức tính chiều cao của cây
    int treeHeight(Node root) {
        if (root == null) return 0; // Nếu gốc null thì chiều cao là 0
        return 1 + Math.max(treeHeight(root.left), treeHeight(root.right)); // Tính chiều cao của cây
    }

    // Phương thức in khoảng trắng
    void printSpaces(int count) {
        for (int i = 0; i < count; i++) { // Duyệt qua số lượng khoảng trắng
            System.out.print(" "); // In khoảng trắng
        }
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree(); // Khởi tạo một cây nhị phân
        Scanner scanner = new Scanner(System.in); // Khởi tạo một Scanner để nhận đầu vào từ người dùng

        System.out.print("Enter the value for the root node:");
        int rootValue = scanner.nextInt(); // Nhận giá trị cho gốc từ người dùng
        tree.root = new Node(rootValue); // Tạo gốc mới với giá trị vừa nhập

        Queue<Node> nodes = new LinkedList<>(); // Khởi tạo một hàng đợi để lưu trữ các node
        nodes.add(tree.root); // Thêm gốc vào hàng đợi

        while (!nodes.isEmpty()) { // Khi hàng đợi không rỗng
            Node currentNode = nodes.poll(); // Lấy và xóa node đầu hàng đợi
            System.out.print("Enter the number of children for node " + currentNode.value + " (0, 1 or 2): ");
            int numChildren = scanner.nextInt(); // Nhận số lượng con của node hiện tại từ người dùng

            if (numChildren > 0) { // Nếu có con trái
                System.out.print("Enter the value for the left child:");
                int leftValue = scanner.nextInt(); // Nhận giá trị cho con trái từ người dùng
                tree.insertNode(currentNode, leftValue, "left"); // Chèn con trái vào cây
                nodes.add(currentNode.left); // Thêm con trái vào hàng đợi
            }

            if (numChildren > 1) { // Nếu có con phải
                System.out.print("Enter the value for the right child: ");
                int rightValue = scanner.nextInt(); // Nhận giá trị cho con phải từ người dùng
                tree.insertNode(currentNode, rightValue, "right"); // Chèn con phải vào cây
                nodes.add(currentNode.right); // Thêm con phải vào hàng đợi
            }
        }

        System.out.println("Breadth-First Search (BFS) traversal of the binary tree:");
        tree.BFS(); // Gọi phương thức BFS để duyệt cây và in giá trị các node
        System.out.println("\nBinary tree structure:");
        tree.printTree(); // Gọi phương thức printTree để in cấu trúc của cây
    }
}
