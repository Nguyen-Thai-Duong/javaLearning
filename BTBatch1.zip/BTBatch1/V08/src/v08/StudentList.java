/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v08;

import java.util.ArrayList;
import java.util.Collections;

/**
 * StudentList: A class representing a list of students. Provides methods to
 * add, delete, search, and display students.
 */
public class StudentList {

    private ArrayList<String> students;// List to store student names
    private static final int MAX_SIZE = 100; // Maximum size of the student list

    /**
     * Constructor for the StudentList class. Initializes the list of students
     * as an empty ArrayList.
     */
    public StudentList() {
        students = new ArrayList<>();
    }

    /**
     * Checks if the given name contains only alphabetic characters.
     *
     * @param name The name to check.
     * @return true if the name contains only alphabetic characters, false
     * otherwise.
     */
    private boolean isAlpha(String name) {
        return name.matches("[a-zA-Z]+");
    }

    /**
     * addStudent: Prompts the user to enter a new student's name and adds it to
     * the student list.
     *
     * @param scanner The Scanner object used to read user input.
     */
    public boolean addStudent(String name) {
        if (students.size() >= MAX_SIZE) {
            System.out.println("The list is full. Cannot add a new student.");
            return false;
        } else if (!isAlpha(name)) {
            System.out.println("Invalid name. Please enter a name with alphabetic characters only.");
            return false;
        } else {
            students.add(name);
            System.out.println("Student has been added to the list successfully!");
            return true;
        }
    }

    /**
     * deleteStudent: Prompts the user to enter a student's name to remove from
     * the student list.
     *
     * @param scanner The Scanner object used to read user input.
     */
    public void deleteStudent(String name) {
        if (students.size() >= MAX_SIZE) {
            System.out.println("The list is full. Cannot add a new student.");
        } else if (!isAlpha(name)) {
            System.out.println("Invalid name. Please enter a name with alphabetic characters only.");
        } else {
            students.add(name);
            System.out.println("Student has been added to the list successfully!");
        }
    }

    /**
     * searchStudent: Prompts the user to enter a student's name to search for
     * in the student list. Prints the position of the student in the list if
     * found.
     *
     * @param scanner The Scanner object used to read user input.
     */
    public int searchStudent(String name) {
        return students.indexOf(name);
    }

    /**
     * displayStudents: Displays the total number of students and their names in
     * ascending order.
     */
    public void displayStudents() {
        Collections.sort(students);// Sort students alphabetically
        System.out.println("Total students: " + students.size());
        for (int i = 0; i < students.size(); i++) {
            System.out.println((i + 1) + ". " + students.get(i));
        }
    }
}





















// thế thẳng vô addStudent luôn

//public boolean addStudent(String name) {
//    if (students.size() >= MAX_SIZE) {
//        System.out.println("The list is full. Cannot add a new student.");
//        return false;
//    } else if (!isAlpha(name)) {
//        System.out.println("Invalid name. Please enter a name with alphabetic characters only.");
//        return false;
//    } else if (students.contains(name)) {
//        System.out.println("Student with this name already exists in the list. Please enter a different name.");
//        return false;
//    } else {
//        students.add(name);
//        System.out.println("Student has been added to the list successfully!");
//        return true;
//    }
//}

// thay hẳng hàm delete để xóa tên trùng
//public void deleteStudent(String name) {
//    if (!isAlpha(name)) {
//        System.out.println("Invalid name. Please enter a name with alphabetic characters only.");
//        return;
//    }
//
//    int count = 0;
//    for (int i = students.size() - 1; i >= 0; i--) {
//        if (students.get(i).equals(name)) {
//            students.remove(i);
//            count++;
//        }
//    }
//
//    if (count == 0) {
//        System.out.println("Student name not found in the list.");
//    } else {
//        System.out.println("Deleted " + count + " occurrence(s) of " + name + " from the list.");
//    }
//}