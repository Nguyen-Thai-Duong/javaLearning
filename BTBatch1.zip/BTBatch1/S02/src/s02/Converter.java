/*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
 */
package s02;

import java.util.Scanner;

/**
 * Class Converter: provides methods to convert hexadecimal and octal numbers to
 * binary.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class Converter {

    /**
     * convertToBinary: prompts the user to enter a hexadecimal or octal number
     * and converts it to binary
     *
     * @param input the input string
     * @return the binary representation of the input, or null if the input is
     * invalid
     */
    public static String convertToBinary(String input) {
        if (input.endsWith("h") || input.endsWith("H")) {
            String hex = input.substring(0, input.length() - 1);
            if (!isValidHex(hex)) {
                return null; // Return null instead of an empty string for invalid input
            }
            return convertHexToBinary(hex);
        } else if (input.endsWith("q") || input.endsWith("Q")) {
            String oct = input.substring(0, input.length() - 1);
            if (!isValidOctal(oct)) {
                return null; // Return null instead of an empty string for invalid input
            }
            return convertOctalToBinary(oct);
        } else {
            return null; // Return null instead of an empty string for invalid input
        }
    }

    /**
     * convertHexToBinary: converts a hexadecimal number to binary
     *
     * @param hex the hexadecimal number
     * @return the binary representation of the hexadecimal number
     */
    private static String convertHexToBinary(String hex) {
        // Implementation code for converting hexadecimal to binary
        StringBuilder bin = new StringBuilder();
        for (int i = 0; i < hex.length(); i++) {
            char hexDigit = hex.charAt(i);
            int hexVal = Character.digit(hexDigit, 16);
            StringBuilder binDigit = new StringBuilder();
            for (int j = 0; j < 4; j++) {
                binDigit.insert(0, hexVal % 2);
                hexVal /= 2;
            }
            bin.append(binDigit);
        }
        for (int i = 4; i < bin.length(); i += 5) {
            bin.insert(i, " ");
        }
        return bin.toString();
    }

    /**
     * convertOctalToBinary: converts an octal number to binary
     *
     * @param oct the octal number
     * @return the binary representation of the octal number
     */
    private static String convertOctalToBinary(String oct) {
        // Implementation code for converting octal to binary
        StringBuilder bin = new StringBuilder();
        for (int i = 0; i < oct.length(); i++) {
            char octDigit = oct.charAt(i);
            int octVal = Character.digit(octDigit, 8);
            StringBuilder binDigit = new StringBuilder();
            for (int j = 0; j < 3; j++) {
                binDigit.insert(0, octVal % 2);
                octVal /= 2;
            }
            bin.append(binDigit);
        }
        for (int i = 3; i < bin.length(); i += 4) {
            bin.insert(i, " ");
        }
        return bin.toString();
    }

    /**
     * isValidHex: checks if the input string is a valid hexadecimal number
     *
     * @param hex the input string
     * @return true if the input is a valid hexadecimal number, false otherwise
     */
    private static boolean isValidHex(String hex) {
        // Implementation code for validating hexadecimal input
        return hex.matches("[0-9A-Fa-f]+");
    }

    /**
     * isValidOctal: checks if the input string is a valid octal number
     *
     * @param oct the input string
     * @return true if the input is a valid octal number, false otherwise
     */
    private static boolean isValidOctal(String oct) {
        // Implementation code for validating octal input
        return oct.matches("[0-7]+");
    }
}
