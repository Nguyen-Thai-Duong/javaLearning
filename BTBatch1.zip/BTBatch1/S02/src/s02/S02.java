/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s02;

import java.util.Scanner;

/**
 * S02 class: Contains the main method to start the program. Converts
 * hexadecimal and octal numbers to binary.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class S02 {

    /**
     * Main method to start the program.
     *
     * @param args The command line arguments
     */
    public static void main(String[] args) {
        // Create an instance of ConverterApplication and run the program
        menu app = new menu();
        app.run();
    }
}
