/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s01;

import java.util.Scanner;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class stringManagement {

    private String input;

    /**
     * Constructor to initialize a StringManagement object with a specified
     * input string.
     *
     * @param inputString The initial value for the input string.
     */
    public stringManagement(String inputString) {
        this.input = inputString;
    }

    /**
     * Method to input a string from the user until a non-empty string is
     * provided. If the input is empty, it displays a prompt.
     */
    public void input() {
        Scanner scanner = new Scanner(System.in);

        // Loop until a non-empty string is provided
        while (input.trim().isEmpty()) {
            System.out.print("Enter a string: ");
            input = scanner.nextLine();

            // If input is empty, display a prompt
            if (input.trim().isEmpty()) {
                System.out.println("Please enter a string.");
            }
        }
    }

    /**
     * Method to create an instance of ReverseAndConvertCase and process the
     * input string.
     *
     * @return The processed string after reversing and converting the case.
     */
    public String reverseAndConvertString() {
        reverseAndConvertCase converter = new reverseAndConvertCase(input);
        return converter.process();
    }

    /**
     * Method to output the result after reversing and converting the string.
     *
     * @param result The result string to be output.
     */
    public void output(String result) {
        System.out.println("        " + result);
    }

}
