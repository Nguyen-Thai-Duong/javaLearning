/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v08;

import java.util.Scanner;

/**
 * StudentManagment: A class that provides a console-based menu for managing a
 * list of students. Allows adding, deleting, searching, and displaying
 * students.
 */
public class StudentManagment {

    private static StudentList studentList = new StudentList();

    /**
     * studentManagment: Manages the interaction with the user through a
     * menu-driven interface. Reads user input to perform operations like
     * adding, deleting, searching, or displaying students.
     */
    public static void studentManagment() {
        Scanner scanner = new Scanner(System.in);
    int choice;

    do {
        showMenu();
        System.out.print("Enter your choice: ");

        // Check if the next token is an int
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number (1-5):");
            scanner.next(); // Consume invalid input
        }

        choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        switch (choice) {
            case 1:
                addStudent(scanner);
                break;
            case 2:
                deleteStudent(scanner);
                break;
            case 3:
                searchStudent(scanner);
                break;
            case 4:
                displayStudents();
                break;
            case 5:
                System.out.println("Exit.");
                break;
            default:
                System.out.println("Choice is not valid, Please choose again (1-5):");
        }
    } while (choice != 5);

    scanner.close();
}

    /**
     * showMenu: Displays a menu with options for managing student information.
     */
    private static void showMenu() {
        System.out.println("\n========== Student Management ==========");
        System.out.println("******************************************");
        System.out.println("1 - Add a student.");
        System.out.println("2 - Remove a student.");
        System.out.println("3 - Search a student.");
        System.out.println("4 - Print list student in an ascending folder.");
        System.out.println("5 - Exit.");
        System.out.println("******************************************");
    }

    /**
     * addStudent: Prompts the user to enter a new student's name and adds it to
     * the student list.
     *
     * @param scanner The Scanner object used to read user input.
     */
     private static void addStudent(Scanner scanner) {
        boolean addedSuccessfully = false;
        do {
            System.out.print("Enter new student name: ");
            String name = scanner.nextLine();
            addedSuccessfully = studentList.addStudent(name);
        } while (!addedSuccessfully);
    }

    /**
     * deleteStudent: Prompts the user to enter a student's name to remove from
     * the student list.
     *
     * @param scanner The Scanner object used to read user input.
     */
    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter student name to remove: ");
        String name = scanner.nextLine();
        studentList.deleteStudent(name);
    }

    /**
     * searchStudent: Prompts the user to enter a student's name to search for
     * in the student list. Prints the position of the student in the list if
     * found.
     *
     * @param scanner The Scanner object used to read user input.
     */
    private static void searchStudent(Scanner scanner) {
        System.out.print("Enter student name to search: ");
        String name = scanner.nextLine();
        int index = studentList.searchStudent(name);
        if (index == -1) {
            System.out.println("Student name doesn’t exist in list.");
        } else {
            System.out.println("The position of student name in list: " + (index + 1));
        }
    }

    /**
     * displayStudents: Displays the total number of students and their names in
     * ascending order.
     */
    private static void displayStudents() {
        studentList.displayStudents();
    }
}
























// thay hoàn toàn addStudent
///**
// * addStudent: Prompts the user to enter a new student's name and adds it to
// * the student list. Handles duplicate name entries by prompting the user to
// * enter a different name.
// *
// * @param scanner The Scanner object used to read user input.
// */
//private static void addStudent(Scanner scanner) {
//    boolean addedSuccessfully = false;
//    do {
//        System.out.print("Enter new student name: ");
//        String name = scanner.nextLine();
//        addedSuccessfully = studentList.addStudent(name);
//    } while (!addedSuccessfully);
//}