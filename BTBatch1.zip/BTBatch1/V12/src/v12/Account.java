/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v12;

import java.io.*;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class Account {

    private String accountNumber;
    private String pin;
    private String accountName;
    private double balance;
    private String currency;

    /**
     * Constructs an Account object.
     *
     * @param accountNumber The account number.
     * @param pin The PIN.
     * @param accountName The account name.
     * @param balance The initial balance.
     * @param currency The currency.
     */
    public Account(String accountNumber, String pin, String accountName, double balance, String currency) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.accountName = accountName;
        this.balance = balance;
        this.currency = currency;
    }

    // Getters and setters
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Converts an Account object to a string for file storage.
     *
     * @return The string representation of the Account.
     */
    @Override
    public String toString() {
        return accountNumber + "," + pin + "," + accountName + "," + balance + "," + currency;
    }

    /**
     * Converts a string to an Account object.
     *
     * @param accountString The string representation of the Account.
     * @return The Account object.
     */
    public static Account fromString(String accountString) {
        String[] parts = accountString.split(",");
        return new Account(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]), parts[4]);
    }
}
