/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s01;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class reverseAndConvertCase {

    private String inputString;

    /**
     * Constructor to initialize the input string
     *
     */
    public reverseAndConvertCase(String inputString) {
        this.inputString = inputString;
    }

    /**
     * Function to reverse and convert a string
     *
     * @return a reversed and converted string
     */
    public String process() {
        StringBuilder reversed = new StringBuilder();

        // Loop through the characters of the input string in reverse order        
        for (int i = 0; i < inputString.length(); i++) {
            char c = inputString.charAt(i);
            // Convert uppercase to lowercase and vice versa
//            if (Character.isUpperCase(c)) {
//                reversed.append(Character.toLowerCase(c));
//            } else 
            if (Character.isLowerCase(c)) {
                reversed.append(Character.toUpperCase(c));
            } else {
                // If the character is neither uppercase nor lowercase, append it unchanged
                reversed.append(c);
            }
        }

        // Return the reversed and case-converted string
        return reversed.toString();
    }
}
