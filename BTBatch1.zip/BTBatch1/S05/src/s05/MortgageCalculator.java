/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s05;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * MortgageCalculator class calculates mortgage payment plan based on user input
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class MortgageCalculator {

    /**
     * input: prompts the user to input mortgage details and calls the
     * calculateMortgage method
     */
    public void input() {
        Scanner scanner = new Scanner(System.in);

        // Input the amount owed, interest rate, and monthly payment
        double amountOwed = 0;
        double annualInterestRate = 0;
        double monthlyPayment = 0;

        try {
            System.out.println("What is the value left on the mortgate?");
            amountOwed = getPositiveInput(scanner);

            System.out.println("What is the annual interest rate of the loan, in percent?");
            annualInterestRate = getPositiveInput(scanner);

            System.out.println("What is the monthly payment?");
            monthlyPayment = getPositiveInput(scanner);
        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter valid numeric values.");
            return;
        }

        // Call the calculateMortgage method to calculate and print the mortgage payment plan
        calculateMortgage(amountOwed, annualInterestRate, monthlyPayment);
    }

    /**
     * getPositiveInput: prompts the user to enter a positive number
     *
     * @param scanner Scanner object to read input
     * @return the positive input value
     */
    private double getPositiveInput(Scanner scanner) {
        double input;
        do {
            input = scanner.nextDouble();
            if (input <= 0) {
                System.out.println("Error: Please enter a positive number.");
                System.out.print("Try again: ");
            }
        } while (input <= 0);
        return input;
    }

    /**
     * calculateMortgage: calculates and prints the mortgage payment plan
     *
     * @param amountOwed the initial amount owed
     * @param annualInterestRate the annual interest rate
     * @param monthlyPayment the monthly payment
     */
    public void calculateMortgage(double amountOwed, double annualInterestRate, double monthlyPayment) {
        double monthlyInterestRate = annualInterestRate / 12 / 100;

        // Check if the monthly payment is too small to pay off the loan
        if (monthlyPayment * (1 - Math.pow(1 + monthlyInterestRate, -1)) / monthlyInterestRate >= amountOwed) {
            System.out.println("Error: Monthly payment is too small to ever pay off the loan.");
            return;
        }

        // Print headers
        System.out.println("Montht\t\tPayment\t\tAmount Owed");

        int month = 1;
        while (amountOwed > 0) {
            double interestAccrued = amountOwed * monthlyInterestRate;
            double newAmountOwed = amountOwed + interestAccrued;
            double actualPayment = Math.min(monthlyPayment, newAmountOwed);

            System.out.printf("%d\t\t$%-10.2f\t$%.2f\n", month, actualPayment, newAmountOwed - actualPayment);

            amountOwed = newAmountOwed - actualPayment;
            month++;
        }
    }
}
