/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v07;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class V07 {

    /**
     * The main method to start the FileManager program.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        // Create a FileManager object
        FileManager fileManager = new FileManager();

        // Show the menu to the user
        fileManager.showMenu();
    }
}
