/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v09;

/**
 *@author Nguyen Thai Duong _ CE180478
 */
public class V09 {

    /**
     * main: The main method of the application. Initializes an instance of
     * ArrayManagement and starts the array management system.
     *
     * @param args The command line arguments (not used in this application).
     */
    public static void main(String[] args) {
        ArrayManagement f = new ArrayManagement();
        f.arrayManagement();
    }

}
