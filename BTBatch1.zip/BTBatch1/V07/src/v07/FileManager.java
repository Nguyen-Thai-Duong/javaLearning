/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v07;

import java.io.*;
import java.nio.file.*;
import java.util.Scanner;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class FileManager {

    /**
     * Reads the contents of a file and prints them to the console.
     *
     * @param fileName The name of the file to be read.
     */
    public void readFile(String fileName) {
        try {
            // Create a File object with the specified file name
            File file = new File(fileName);

            // Create a Scanner object to read the file
            Scanner reader = new Scanner(file);

            // Read and print each line of the file
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                System.out.println(line);
            }

            // Close the scanner
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }

    /**
     * Copies a file from the source path to the target path.
     *
     * @param sourceFile The source file path.
     * @param targetFile The target file path.
     */
    public void copyFile(String sourceFile, String targetFile) {
        try {
            // Use the Files class to copy the file from source to target
            Files.copy(Paths.get(sourceFile), Paths.get(targetFile), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while copying the file.");
            e.printStackTrace();
        }
    }

    /**
     * Merges the contents of two files into a target file.
     *
     * @param file1 The path of the first file.
     * @param file2 The path of the second file.
     * @param targetFile The target file where contents will be merged.
     */
    public void mergeFiles(String file1, String file2, String targetFile) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(targetFile))) {
            // Read and write lines from the first file to the target file
            Files.lines(Paths.get(file1)).forEach(line -> {
                try {
                    writer.write(line);
                    writer.newLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            // Read and write lines from the second file to the target file
            Files.lines(Paths.get(file2)).forEach(line -> {
                try {
                    writer.write(line);
                    writer.newLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
   
            System.out.println("Files merged successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while merging the files.");
            e.printStackTrace();
        }
    }

    /**
     * Lists all files in the current directory.
     */
    public void listFiles() {
        // Create a File object for the current directory
        File folder = new File(".");

        // Get a list of all files in the directory
        File[] listOfFiles = folder.listFiles();

        // Iterate through the list and print the name of each file
        for (File file : listOfFiles) {
            if (file.isFile()) {
                System.out.println(file.getName());
            }
        }
    }

    /**
     * Deletes a file from the specified path.
     *
     * @param fileName The name of the file to be deleted.
     */
    public void deleteFile(String fileName) {
        // Create a File object with the specified file name
        File file = new File(fileName);

        // Attempt to delete the file and print the result
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("An error occurred while deleting the file.");
        }
    }

    /**
     * Displays a menu for the user to choose various file operations. Keeps
     * prompting the user until the exit option is chosen.
     */
    public void showMenu() {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        // Continue to show the menu until the user chooses to exit
        while (choice != 6) {
            System.out.println("\nChoose an option:");
            System.out.println("1) Read files");
            System.out.println("2) Copy files");
            System.out.println("3) Merge two files");
            System.out.println("4) List files in a directory");
            System.out.println("5) Delete files");
            System.out.println("6) Exit");

            System.out.print("Choice features: ");

            // Check if the user input is a valid integer
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline left-over

                switch (choice) {
                    case 1:
                        // Handle the Read files option
                        String readFile;
                        do {
                            System.out.print("Enter the file name to read: ");
                            readFile = scanner.nextLine();
                            if (!new File(readFile).exists()) {
                                System.out.println("File does not exist. Please enter a valid file name.");
                            }
                        } while (!new File(readFile).exists());
                        readFile(readFile);
                        break;
                    case 2:
                        // Handle the Copy files option
                        String sourceFile;
                        do {
                            System.out.print("Enter the source file name: ");
                            sourceFile = scanner.nextLine();
                            if (!new File(sourceFile).exists()) {
                                System.out.println("Source file does not exist. Please enter a valid file name.");
                            }
                        } while (!new File(sourceFile).exists());
                        System.out.print("Enter the target file name: ");
                        String targetFile = scanner.nextLine();
                        copyFile(sourceFile, targetFile);
                        break;
                    case 3:
                        // Handle the Merge two files option
                        String file1,
                         file2;
                        do {
                            System.out.print("Enter the first file name: ");
                            file1 = scanner.nextLine();
                            if (!new File(file1).exists()) {
                                System.out.println("First file does not exist. Please enter a valid file name.");
                            }
                        } while (!new File(file1).exists());
                        do {
                            System.out.print("Enter the second file name: ");
                            file2 = scanner.nextLine();
                            if (!new File(file2).exists()) {
                                System.out.println("Second file does not exist. Please enter a valid file name.");
                            }
                        } while (!new File(file2).exists());
                        System.out.print("Enter the target file name: ");
                        String mergeTargetFile = scanner.nextLine();
                        mergeFiles(file1, file2, mergeTargetFile);
                        break;
                    case 4:
                        // Handle the List files in a directory option
                        listFiles();
                        break;
                    case 5:
                        // Handle the Delete files option
                        String deleteFile;
                        do {
                            System.out.print("Enter the file name to delete: ");
                            deleteFile = scanner.nextLine();
                            if (!new File(deleteFile).exists()) {
                                System.out.println("File does not exist. Please enter a valid file name.");
                            }
                        } while (!new File(deleteFile).exists());
                        deleteFile(deleteFile);
                        break;
                    case 6:
                        // Handle the Exit option
                        System.out.println("Exiting the program.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 6.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number between 1 and 6.");
                scanner.next(); // Consume the invalid input
            }
        }
    }
}
