/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s01;

import java.util.Scanner;

/**
 * Reverse a string; convert to upper case and vice versa.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class S01 {

    /**
     * The main method to initialize a StringManagement object, input data,
     * perform string reversal and conversion, and output the result.
     *
     * @param args The command line arguments (not used in this program).
     */
    public static void main(String[] args) {
        // Initialize a StringManagement object with an empty string
        stringManagement strmn = new stringManagement("");
        // Input data for the StringManagement object
        strmn.input();
        // Perform string reversal and conversion according to specific rules
        String result = strmn.reverseAndConvertString();
        // Output the result after reversing and converting the string
        strmn.output(result);
    }
}
