/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l03;

import java.util.ArrayList;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class Order {
  private String customerName;
    private ArrayList<Fruit> fruits;
    private ArrayList<Integer> quantities;

    public Order(String customerName) {
        this.customerName = customerName;
        this.fruits = new ArrayList<>();
        this.quantities = new ArrayList<>();
    }

    public void addFruit(Fruit fruit, int quantity) {
        fruits.add(fruit);
        quantities.add(quantity);
    }

    public String getCustomerName() {
        return customerName;
    }

    public ArrayList<Fruit> getFruits() {
        return fruits;
    }

    public ArrayList<Integer> getQuantities() {
        return quantities;
    }

    public double getTotal() {
        double total = 0;
        for (int i = 0; i < fruits.size(); i++) {
            total += fruits.get(i).getPrice() * quantities.get(i);
        }
        return total;
    }
}
