package v06;

import java.util.Scanner;

/**
 * A class to manage array manipulation operations such as input array, sorting
 * array in ascending and descending order, and displaying menu.
 */
public class ArraySorter {

    private static Scanner scanner = new Scanner(System.in);
    private static int[] array;

    /**
     * Display the menu and handle user input for array manipulation.
     */
    public static void displayMenu() {
        // Display menu options and repeatedly prompt user for input
        while (true) {
            System.out.println("========= Bubble Sort program =========");
            System.out.println("1. Input Element");
            System.out.println("2. Sort Accending");
            System.out.println("3. Sort Descending");
            System.out.println("4. Sum Odd Numbers");
            System.out.println("5. Exit");
            System.out.print("Please choice one option: ");
            int option = checkInput();
            executeOption(option);
        }
    }

    /**
     * Execute the selected option based on user input.
     *
     * @param option The option selected by the user.
     */
    public static void executeOption(int option) {
        switch (option) {
            case 1:
                inputArray();
                break;
            case 2:
                displaySortedArray(sortAscending(array), "ascending");
                break;
            case 3:
                displaySortedArray(sortDescending(array), "descending");
                break;
            case 4:
                int sumOdd = sumOddNumbers(array);
                System.out.println("Sum of odd numbers: " + sumOdd);
                break;
            case 5:
                System.out.println("Exiting program. Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Please input a number 1 to 5.");
        }
    }

    /**
     * Input an array from user.
     */
    private static void inputArray() {
        System.out.print("Enter number: ");
        int length = checkInput();
        array = new int[length];
        for (int i = 0; i < length; i++) {
            System.out.print("Enter Number " + (i + 1) + ": ");
            array[i] = checkInput();
        }
    }

    /**
     * Display the sorted array with arrows indicating the order.
     *
     * @param sortedArray The sorted array to be displayed.
     */
    private static void displaySortedArray(int[] sortedArray, String order) {
        if (order.equals("ascending")) {
            System.out.println("----- Ascending -----");
            for (int i = 0; i < sortedArray.length; i++) {
                System.out.print("[" + sortedArray[i] + "]");
                if (i < sortedArray.length - 1) {
                    System.out.print("->");
                }
            }
            System.out.println();
        } else if (order.equals("descending")) {
            System.out.println("----- Descending -----");
            for (int i = sortedArray.length - 1; i >= 0; i--) {
                System.out.print("[" + sortedArray[i] + "]");
                if (i > 0) {
                    System.out.print("<-");
                }
            }
            System.out.println();
        }
    }

    /**
     * Sort the array in ascending order using the bubble sort algorithm.
     *
     * @param array The array to be sorted.
     * @return The sorted array in ascending order.
     */
    private static int[] sortAscending(int[] array) {
        // Create a copy of the original array to avoid modifying it
        int[] sortedArray = array.clone();
        int n = sortedArray.length;
        // Perform bubble sort algorithm
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                // Swap adjacent elements if they are in the wrong order
                if (sortedArray[j] > sortedArray[j + 1]) {
                    int temp = sortedArray[j];
                    sortedArray[j] = sortedArray[j + 1];
                    sortedArray[j + 1] = temp;
                }
            }
        }
        // Return the sorted array
        return sortedArray;
    }

    /**
     * Sort the array in descending order using the bubble sort algorithm.
     *
     * @param array The array to be sorted.
     * @return The sorted array in descending order.
     */
    private static int[] sortDescending(int[] array) {
        // Create a copy of the original array to avoid modifying it
        int[] sortedArray = array.clone();
        int n = sortedArray.length;
        // Perform bubble sort algorithm
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                // Swap adjacent elements if they are in the wrong order
                if (sortedArray[j] < sortedArray[j + 1]) {
                    int temp = sortedArray[j];
                    sortedArray[j] = sortedArray[j + 1];
                    sortedArray[j + 1] = temp;
                }
            }
        }
        // Return the sorted array
        return sortedArray;
    }
    
      private static int sumOddNumbers(int[] array) {
        int sum = 0;
        for (int num : array) {
            if (num % 2 != 0) {
                sum += num;
            }
        }
        return sum;
    }

    /**
     * Check if the user input is a positive integer.
     *
     * @return The positive integer input by the user.
     */
    private static int checkInput() {
        while (true) {
            try {
                String input = scanner.nextLine();
                int number = Integer.parseInt(input);
                if (number > 0) {
                    return number;
                } else {
                    System.out.println("Please enter a positive integer.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }
}
