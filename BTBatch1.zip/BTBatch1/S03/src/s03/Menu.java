/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s03;

import java.util.Scanner;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class Menu {

    public static void main(String[] args) {
        NumericConverter converter = new NumericConverter();
        Menu menu = new Menu(converter);
        menu.display();
    }

    private NumericConverter converter;
    private Scanner scanner;

    public Menu(NumericConverter converter) {
        this.converter = converter;
        this.scanner = new Scanner(System.in);
    }

    public void display() {
        while (true) {
            System.out.print("Please enter string in numeric format: ");
            String input = scanner.nextLine();

            try {
                int number = Integer.parseInt(input);
                String result = converter.convertNumberToWords(number);
                System.out.println("The converted string: " + result);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid numeric string.");
                continue; // Restart the loop if input is invalid
            }

            String choice;
            do {
                System.out.print("Do you want to continue? (Y/N) ");
                choice = scanner.nextLine().trim().toUpperCase();
                if (!choice.equals("Y") && !choice.equals("N")) {
                    System.out.println("Invalid choice. Please enter 'Y' or 'N'.");
                }
            } while (!choice.equals("Y") && !choice.equals("N"));

            if (choice.equals("N")) {
                break;
            }
        }
    }
}
