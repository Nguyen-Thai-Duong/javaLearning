/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v09;

import java.awt.BorderLayout;
import java.util.Scanner;

/**
 * ArrayManagement: A class that provides operations to manage an array of integers.
 * Allows adding, searching, removing, printing, and sorting operations on the array.
 */
public class ArrayManagement {

    private static final int MAX_SIZE = 100; // Maximum size of the array
    private static int[] array = new int[MAX_SIZE]; // Array to store integers
    private static int size = 0; // Current size of the array

    
    /**
     * arrayManagement: Manages interaction with the user through a menu-driven interface.
     * Reads user input to perform operations like adding, searching, removing, printing, and sorting on the array.
     */
    public static void arrayManagement() {
        Scanner sc = new Scanner(System.in);

        int choice;

        do {
            System.out.println("==========MENU=========");
            System.out.println("1- Add value");
            System.out.println("2- Search value");
            System.out.println("3- Removes the first existence of a value");
            System.out.println("4- Eliminates all existence of a value");
            System.out.println("5- Print array");
            System.out.println("6- Sort the array in ascending order");
            System.out.println("7- Sort the array in descending order");
            System.out.println("8- Exit");
            System.out.println("========================");
            System.out.print("Please enter your choice (1-8): ");
            while (!sc.hasNextInt()) {
                System.out.println("Choice is not valid, please enter choice again (1-8): ");
                sc.next();
            }
            choice = sc.nextInt(); 
            
            switch (choice) {
                case 1:
                    addValue(sc);
                    break;
                case 2:
                    searchValue(sc);
                    break;
                case 3:
                    removeFirtArry(sc);
                    break;
                case 4:
                    removeAllArray(sc);
                    break;
                case 5:
                    printArray();
                    break;
                case 6:
                    bubbleSortAscending();
                    break;
                case 7:
                    bubbleSortDescending();
                    break;
                case 8:
                    System.out.println("**********EXIT**********");
                default:
                    System.out.println("Choice is not valid, Pleas choice again(1-8): ");
            }
        } while (choice != 8);
    }

  /**
     * addValue: Adds a new integer value to the array.
     *
     * @param sc The Scanner object used to read user input.
     */
    public static void addValue(Scanner sc) {
        if (size < MAX_SIZE) {
            System.out.print("Enter an interger:");
            while (!sc.hasNextInt()) {
                System.out.print("Invalid input,Please enter an interger:");
                sc.next();
            }
            int value = sc.nextInt();
            array[size++] = value;
            System.out.println("Added value to array");
        } else {
            System.out.println("The array is full, new values ​​cannot be added.");
        }
    }

   /**
     * searchValue: Searches for a value in the array.
     *
     * @param sc The Scanner object used to read user input.
     */
    public static void searchValue(Scanner sc) {
        System.out.print("Enter values to find: ");

        while (!sc.hasNextInt()) {
            System.out.println("INVALID input, please enter value to find:");
            sc.next();
        }
        int value = sc.nextInt();
        for (int i = 0; i < size; i++) {
            if (array[i] == value) {
                System.out.println("Value " + value + " found at index" + i);
                return;
            }
        }
        System.out.println("NOT found value " + value + " in array");
    }

     /**
     * removeFirstArray: Removes the first occurrence of a value from the array.
     *
     * @param sc The Scanner object used to read user input.
     */
    public static void removeFirtArry(Scanner sc) {
        System.out.print("Enter value to remove first and last occurrences:");
    while (!sc.hasNextInt()) {
        System.out.println("INVALID input, please enter value to remove first and last occurrences: ");
        sc.next();
    }
    int value = sc.nextInt();
    int firstIndex = -1;
    int lastIndex = -1;

    for (int i = 0; i < size; i++) {
        if (array[i] == value) {
            if (firstIndex == -1) {
                firstIndex = i;
            }
            lastIndex = i;
        }
    }

    if (firstIndex != -1) {
        for (int i = firstIndex; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        size--;
    }

    if (lastIndex != -1 && lastIndex != firstIndex) {
        for (int i = lastIndex - 1; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        size--;
    }

    if (firstIndex != -1) {
        System.out.println("Removed the first and last occurrences of value " + value + " in the array.");
    } else {
        System.out.println("NOT found value " + value + " in array");
    }
}

   /**
     * removeAllArray: Removes all occurrences of a value from the array.
     *
     * @param sc The Scanner object used to read user input.
     */
    public static void removeAllArray(Scanner sc) {
        System.out.print("Enter value to remove all:");
        while (!sc.hasNextInt()) {
            System.out.println("INVALID input, please enter value to remove all: ");
            sc.next();
        }
        int value = sc.nextInt();
        int newsize = 0;

        for (int i = 0; i < size; i++) {
            if (array[i] != value) {
                array[newsize++] = array[i];
            }
        }
        int removedCount = size - newsize;
        size = newsize;
        System.out.println("Removed " + removedCount + " occurrences of value " + value + " in the array.");
    }

     /**
     * printArray: Prints all elements of the array.
     */
    public static void printArray() {
        System.out.println("Array: ");
        for (int i = 0; i < size; i++) {
            System.out.println(array[i] + "");
        }
        System.out.println();
    }

    /**
     * bubbleSortAscending: Sorts the array in ascending order using bubble sort algorithm.
     */
    public static void bubbleSortDescending() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - 1 - i; j++) {
                if (array[j] < array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
        System.out.println("Sorted array in descending order.");
    }

    /**
     * bubbleSortDescending: Sorts the array in descending order using bubble sort algorithm.
     */
    private static void bubbleSortAscending() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - 1 - i; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
        System.out.println("Sorted array in ascending order.");
    }
}
