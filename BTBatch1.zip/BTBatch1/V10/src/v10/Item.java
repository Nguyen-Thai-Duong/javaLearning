/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v10;

/*
 * Item class represents an item in a grocery store with attributes like id, name, cost, and category.
 */
public class Item {
    int id;
    String name;
    double  cost;
    String category;

    /**
     * Constructor to initialize an Item object with provided attributes.
     * @param id The unique identifier of the item.
     * @param name The name of the item.
     * @param cost The cost of the item.
     * @param category The category of the item.
     */
    public Item(int id, String name, double cost, String category) {
        this.id = id;
        this.name = name;
        this.cost = cost;
        this.category = category;
    }
    
    /**
     * Override method to format the Item details as a string.
     * @return Formatted string representation of the Item.
     */
   @Override
public String toString() {
    String formattedName = name.length() > 15 ? name.substring(0, 15) : name;
    return String.format("%-10d %-15s %-10.2f %-15s", id, formattedName, cost, category);
}
}


