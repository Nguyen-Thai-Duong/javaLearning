/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s07;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class InputHandler {
    private Scanner scanner;

    /**
     * Constructor to initialize the scanner.
     */
    public InputHandler() {
        scanner = new Scanner(System.in);
    }

    /**
     * Get the size of the array from user input.
     * This method will prompt the user until a valid size is entered.
     *
     * @return The size of the array.
     */
    public int getSize() {
        int size = -1;
        while (size <= 0) {
            try {
                System.out.print("Please enter size of array: ");
                size = scanner.nextInt();
                if (size <= 0) {
                    System.out.println("Size must be a positive integer. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a positive integer.");
                scanner.next(); // clear the invalid input
            }
        }
        return size;
    }

    /**
     * Get an element of the array from user input.
     * This method will prompt the user until a valid integer is entered.
     *
     * @param index The index of the element.
     * @return The value of the element.
     */
    public int getElement(int index) {
        int element = 0;
        boolean valid = false;
        while (!valid) {
            try {
                System.out.print("Element[" + index + "] = ");
                element = scanner.nextInt();
                valid = true;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.next(); // clear the invalid input
            }
        }
        return element;
    }
}