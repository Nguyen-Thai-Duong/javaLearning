/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s07;
import java.util.Arrays;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class ArrayManager {
      private int[] array;

    /**
     * Constructor to initialize the array with a given size.
     *
     * @param size The size of the array.
     */
    public ArrayManager(int size) {
        array = new int[size];
    }

    /**
     * Sets the value of an element at a specified index.
     *
     * @param index The index of the element.
     * @param value The value to set.
     */
    public void setElement(int index, int value) {
        array[index] = value;
    }

    /**
     * Displays the original array.
     */
    public void displayOriginalArray() {
        System.out.println("The original array:");
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    /**
     * Removes duplicate elements from the array.
     * This method uses Java Streams to find and remove duplicates.
     */
    public void removeDuplicates() {
        int[] tempArray = Arrays.stream(array).distinct().toArray();
        array = Arrays.copyOf(tempArray, tempArray.length);
    }

    /**
     * Displays the array after removing duplicate elements.
     */
    public void displayArray() {
        System.out.println("The array after removing duplicate elements:");
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
