/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v01;

/**
 * Class V01: The main entry point for the LuckyNumberGame.
 * 
 * @author Nguyen Thai Duong _ CE180478
 */
public class V01 {
/**
     * main: Entry point of the program. Creates an instance of LuckyNumberGame and starts the game.
     *
     * @param args Command-line arguments (not used in this program)
     */
    public static void main(String[] args) {
        LuckyNumberGame game = new LuckyNumberGame();
        game.runGame();
    }
}
