package v01;

import java.util.Random;
import java.util.Scanner;

/**
 * Class LuckyNumberGame: Implements a guessing game where the user tries to
 * guess a randomly generated lucky number within a specified range.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class LuckyNumberGame {

    // Định nghĩa hằng số maximum
    private static final int MAXIMUM = 10;

    // Khai báo các biến lưu thông tin trò chơi
    private int totalGames = 0;
    private int totalGuesses = 0;
    private int bestGame = Integer.MAX_VALUE;
    private int sumOfAllGuesses = 0;
    private int maxGuess = Integer.MIN_VALUE; // Biến để lưu số lớn nhất trong tất cả các lượt chơi

    /**
     * runGame: starts and manages the lucky number guessing game. Uses Scanner
     * object to get user input.
     */
    public void runGame() {
        Scanner scanner = new Scanner(System.in);
        boolean keepPlaying;

        do {
            play(scanner);
            keepPlaying = askToPlayAgain(scanner);
        } while (keepPlaying);

        report();
        scanner.close();
    }

    /**
     * play: runs a single instance of the game where the user guesses the lucky
     * number.
     *
     * @param scanner Scanner object to read user input
     */
    private void play(Scanner scanner) {
        Random random = new Random();
        int luckyNumber = random.nextInt(MAXIMUM + 1);
        int guess;
        int guessesThisGame = 0;

        System.out.println("Welcome to the Lucky Number Game!");
        System.out.println("I have selected a lucky number between 0 and " + MAXIMUM + ". Can you guess what it is?");

        do {
            System.out.print("Enter your guess: ");

            // Kiểm tra nếu người dùng nhập vào một số nguyên hợp lệ
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input! Please enter a valid integer.");
                System.out.print("Enter your guess: ");
                scanner.next(); // Đọc và loại bỏ dữ liệu không hợp lệ
            }
            guess = scanner.nextInt();
            guessesThisGame++;
            sumOfAllGuesses += guess; // Cộng giá trị dự đoán vào tổng số người chơi đã nhập

            // Cập nhật giá trị lớn nhất
            if (guess > maxGuess) {
                maxGuess = guess; //guess = maxGuess;
            }

            if (guess > luckyNumber) {
                System.out.println("The lucky number is smaller than your guess.");
            } else if (guess < luckyNumber) {
                System.out.println("The lucky number is larger than your guess.");
            } else {
                System.out.println("Congratulations! You've guessed the lucky number in " + guessesThisGame + " tries.");
            }
        } while (guess != luckyNumber);

        totalGames++;
        totalGuesses += guessesThisGame;
        if (guessesThisGame < bestGame) {
            bestGame = guessesThisGame;
        }
    }

    /**
     * askToPlayAgain: prompts the user if they want to play the game again.
     *
     * @param scanner Scanner object to read user input
     * @return true if user wants to play again, false otherwise
     */
    private boolean askToPlayAgain(Scanner scanner) {
        System.out.print("Do you want to play again? (yes/no): ");
        String response = scanner.next();
        return response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes");
    }

    /**
     * report: displays a summary of game statistics. Calculates average guesses
     * per game and average of all guesses.
     */
    private void report() {
        double averageGuess = (double) sumOfAllGuesses / totalGuesses; // Tính trung bình cộng

        System.out.println("Game Summary:");
        System.out.println("Total games played: " + totalGames);
        System.out.println("Total guesses: " + totalGuesses);
        System.out.println("Average guesses per game: " + (totalGuesses / (double) totalGames));
        System.out.println("Best game (fewest guesses): " + bestGame);
        // System.out.println("Sum of all guesses: " + sumOfAllGuesses); // In ra tổng tất cả các số người chơi đã nhập
        //System.out.println("Average of all guesses: " + averageGuess); // In ra trung bình cộng tất cả các số người chơi đã nhập
         System.out.println("Largest guess in all games: " + maxGuess); // In ra số lớn nhất trong tất cả các lượt chơi
    }
}
