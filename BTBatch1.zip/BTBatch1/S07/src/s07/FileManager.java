/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s07;

/**
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class FileManager {
      /**
     * Show the menu to the user and handle the program flow.
     * This method coordinates the user input, array management, and display.
     */
    public void showMenu() {
        // Create an InputHandler to get user inputs
        InputHandler inputHandler = new InputHandler();

        // Get the size of the array from the user
        int size = inputHandler.getSize();

        // Create an ArrayManager to manage the array
        ArrayManager arrayManager = new ArrayManager(size);

        // Get each element of the array from the user
        for (int i = 0; i < size; i++) {
            arrayManager.setElement(i, inputHandler.getElement(i));
        }

        // Display the original array
        arrayManager.displayOriginalArray();

        // Remove duplicate elements from the array
        arrayManager.removeDuplicates();

        // Display the array after removing duplicates
        arrayManager.displayArray();
    }
}
