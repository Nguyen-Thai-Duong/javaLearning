/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s02;

/**
 * OutputHandler class: Provides methods to handle output, specifically for
 * displaying binary representation and error messages.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class OutputHandler {

    /**
     * displayBinary: Displays the binary representation of a number.
     *
     * @param binary The binary representation to display
     */
    public void displayBinary(String binary) {
        if (binary.equals("Invalid input!!!")) {
            System.out.println(binary);
        } else {
            System.out.println("Binary number: " + binary + "b");
        }
    }

    /**
     * getErrorMessage: Retrieves the error message for invalid input.
     *
     * @return The error message for invalid input
     */
    public String getErrorMessage() {
        return "Invalid input!!!";
    }
}
