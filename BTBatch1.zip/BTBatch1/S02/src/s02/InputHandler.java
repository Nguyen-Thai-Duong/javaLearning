/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s02;

import java.util.Scanner;

/**
 * InputHandler class: Provides methods to handle user input for converting
 * hexadecimal or octal numbers to binary.
 *
 * @author Nguyen Thai Duong _ CE180478
 */
public class InputHandler {

    private Scanner scanner = new Scanner(System.in);

    /**
     * getInput: Prompts the user to enter a hexadecimal or octal number.
     *
     * @return The input string entered by the user.
     */
    public String getInput() {
        System.out.println("Convert Hexadecimal number/Octal number to Binary program");
        System.out.print("Enter a Hexadecimal (h)/Octal (q) number: ");
        return scanner.nextLine();
    }

    /**
     * waitForInput: Waits for the user to press any key to continue.
     */
    public void waitForInput() {
        System.out.println("Press any key to do another conversion.");
        scanner.nextLine();
    }
}
